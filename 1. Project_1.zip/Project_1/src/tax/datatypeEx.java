package tax;

public class datatypeEx {

	public static void main(String[] args) {
	
		byte b=11; // -128 to +127
		short s =333;
		int i =44455;
		long l =5433333;
		
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		
		
		///
		float data =444.2333f;
		double db = 443444.3333;
		
		System.out.println(data);
		System.out.println(db);
		

		//char
		char c ='&';
		System.out.println(c);

		//bit
		boolean bo = true;
		System.out.println(bo);
		
		//String 
		String ss ="hi this is first java code!!! 1233";
		System.out.println(ss);
		
		
		
	}

}
