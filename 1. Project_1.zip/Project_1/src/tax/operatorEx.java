package tax;

public class operatorEx {

	public static void main(String[] args) {
	
		int i,j;
		i =0;
		j =0;
		
		System.out.println(i++);//		0
		System.out.println(++j);//		1
		
		System.out.println(i);//1
		System.out.println(j);//1

		///
		int o;
		o = 2+3*4;  //14
		System.out.println(o);
		
		o = (2+3)*4; // 20
		System.out.println(o);
		
		o =85/10; // 8
		System.out.println(o);
		
		o = 85%10; // 5
		System.out.println(o);
			
		
		int nn =456;
		int n1,n2,n3;
		n1 =nn/100; //1		
		n2 =(nn/10)%10; //2
		n3 =nn%10; //3
		
		System.out.print(n3);
		System.out.print(n2);
		System.out.print(n1);
		
		
		
		
		
		
		
	}

}
