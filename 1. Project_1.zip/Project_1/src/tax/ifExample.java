package tax;

import java.util.Scanner;

public class ifExample {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int hs,es,cs,ms,total,avg;
		
		System.out.println("enter marks in hindi :");
		hs = sc.nextInt();
		
		System.out.println("enter marks in english :");
		es = sc.nextInt();
		
		System.out.println("enter marks in computer :");
		cs = sc.nextInt();
		
		System.out.println("enter marks in maths :");
		ms = sc.nextInt();
		
		
		total = hs+es+cs+ms;
		avg = total/4;
		
		System.out.println("total score is "+total);
		System.out.println("average score is "+avg);

		//show grade 
		if(avg>=80)
		{
			System.out.println("A");
		}
		else if(avg>=60)
		{
			System.out.println("B");
		}
		else if(avg>=50)
		{
			System.out.println("C");
		}
		else
		{
			System.out.println("D");
		}
		
		
	}

}
