package tax;

import java.util.Scanner;

public class inputAndOutputEx {

	public static void main(String[] args) {
		
		//here Scanner is class , and s is object 
		//new : is keyword which allocates the memory
		//System.in : take input / input direction 
		Scanner s = new Scanner(System.in);
		int n;
		String name;
		
		
		System.out.println("enter data : ");
		n =s.nextInt();//here nextInt() is inbuilt function 
		
		
		System.out.println("enter name : ");
		name =s.next();
	
						
		System.out.println("you have entered : "+n);
		System.out.println("your name is : "+name);
		

	}

}
