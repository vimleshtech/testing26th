package tax;

public class test1 
{
	//data member
	int a;
	static int b;	
	String name;
	
	//function / method 
	public static void main(String[] arg) 
	{
		int a,b,c; //here int is data type , a,b,c are variables
		a =22;
		b =44;
		
		c=a+b;  //logic / expression 
		
		System.out.println(c); //change the line print 
		
		System.out.print("hi"); //no line change
		System.out.print("hello"); //no line change
		
			

	}

}
