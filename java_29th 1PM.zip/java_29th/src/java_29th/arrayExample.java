package java_29th;

public class arrayExample {

	public static void main(String[] args) {

		int a[] = new int[5]; //here 5 is size of array 
		a[0]  =13;
		a[1]  =12;
		a[2]  =13;
		a[3]  =1222;
		a[4]  =133;
		
		//access array element 
		System.out.println(a[2]); //13
		
		for(int i=0; i<a.length;i++)
			System.out.println(a[i]);

		//or
		for(int b:a)
			System.out.println(b);

		
		//example 2
		int d[] = {111,22,3,4333,21,22,22,3};
		//show count of 3
		//shwo sum of all numbers
		int c =0;
		int s =0;
		for(int b:d)
		{
			s+=b;
			if(b==3)
				c++;
			
		}
		System.out.println("count of 3 :"+c);
		System.out.println("sum of all elements :"+s);
		
		
		
	}

}
