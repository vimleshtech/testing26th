package java_29th;

public class twodArray {

	public static void main(String[] args) {
		
		
		
		String emp[][] = new String[2][3];  // 2 rows and 3 cols
		
		emp[0][0] = "nitin";
		emp[0][1] = "male";
		emp[0][2] = "delhi";
		
		emp[1][0] = "raman";
		emp[1][1] = "male"; 
		emp[1][2] = "pune";
		//access element
		System.out.println(emp[1][1]); //male

		//
		for(String row[]:emp)
		{
			for(String c:row)
			{
				System.out.print(c+"\t");
			}
			System.out.println();
		}

	}

}
