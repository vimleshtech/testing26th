package java_29th;

import java.util.Scanner;

public class functionEx {

	public static void main(String[] args) 
	{
		//invoke /call to functions
		welcome();
		//welcome();
		
		int a= getNum();
		int b= getNum();
		
		
		add(a,b);
		add(getNum(),getNum());
		
		
	}
	
	//no argument no return
	public static void welcome()
	{
		System.out.println("welcome to function world..!!!!");
	}
	
	//no argument with return
	public static int getNum() 
	{
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter data  :");
		n =sc.nextInt();
		return n;
	}

	//argument with no return
	public static void add(int a, int b)
	{
		int c=a+b;
		System.out.println(c);
	}
	//argument with return
	public static int sub(int a, int b)
	{
		int c =a-b;
		return c;
	}
}
