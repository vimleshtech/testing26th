package java_29th;

import java.net.SocketTimeoutException;
import java.util.Scanner;

public class loopQuestions {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter data: ");
		int t =  sc.nextInt(); //here nextInt() is method 
		
		//3 6 9 ...30
		for(int i=1; i<=10;i++)
		{
			System.out.println(t*i);
		}
		
		////////
		String ss="";
		
		for(int i=1; i<=10;i++)
		{
			ss +="*";
			System.out.println(ss);
		}
		
		System.out.println(ss);
		
		for(int i=10; i>0;i--)
		{			
			System.out.println(ss.substring(0,i));
		}
		
	}

}
