package java_29th;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class fileHandlingEx {

	public static void writerToFile() throws IOException
	{
		// 
			FileWriter fw =new FileWriter ("C:\\Users\\vkumar15\\Desktop\\backup\\output.txt");			 
			BufferedWriter br = new BufferedWriter(fw);
				
			br.write("hi");
			br.newLine();
			br.write("hello");
			br.close();
			fw.close();
	}
	public static void main(String[] args) throws IOException 
	{
		writerToFile();

		//load file from physical location 
		FileReader fr =new FileReader("C:\\Users\\vkumar15\\Desktop\\backup\\PowerShell.txt");
		//read data in object format 
		BufferedReader br = new BufferedReader(fr);
		
		String data="";
		
		//read line by line
		while( (data = br.readLine() ) !=null)
		{
			System.out.println(data);
		}
		
		br.close();
		fr.close();
			
		

	}

}
