package java_29th;

public class stringQuestions {

	public static void main(String[] args) 
	{
	
		String s ="this is java code.java is programing language";
		
		//int l = s.length();//14
		//int l1 = s.replace(" ", "").length();//11		
		//System.out.println(l-l1);
			
		System.out.println(s.length()-s.replace(" ","").length());
		
		
		//get count of is word?
		String wd[]=s.split(" ");
		//["this","is","java","code","java","is","prog..","la"]
		int counter=0;
		
		for(String x: wd)
		{
			if(x.equals("is"))
				counter++;
		}
		
		
		System.out.println("is count ?"+counter);

	}

}
