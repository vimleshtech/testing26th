package java_29th;

import java.util.Scanner;

public class exceptionEx {

	public static void main(String[] args) {

		int n,d,o;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter data : ");
		n =sc.nextInt();
		
		System.out.println("enter divisor : ");
		d =sc.nextInt();
		
		try 
		{
			if(d<0) 
			{
			
				Exception eo = new Exception("divisor cannot be less than 0");
				throw eo;
				
				
			}
			o =n/d;		
			System.out.println(o);
		}
		catch (ArithmeticException e) {
			
			System.out.println("arithmetic issues ");
		}
		catch (ArrayIndexOutOfBoundsException e) {
			
		}
		catch (Exception e) //here Exception is inbuilt class , and e is object 
		{
			System.out.println(e);
		}
		finally {
			System.out.println("end of code");
		}
		o = n+d;
		System.out.println("sum of two number :"+o);
	}

}
