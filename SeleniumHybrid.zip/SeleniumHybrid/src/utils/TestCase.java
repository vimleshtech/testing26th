package utils;

public class TestCase {

	String tid;
	String testcase;
	String prereq;
	String steps;
	String input;
	String expout;
	
	TestCase(String tid,	String testcase,	String prereq,	String steps,	String input,	String expout	)
	{
		this.tid = tid;
		this.testcase = testcase;
		this.prereq = prereq;
		this.steps = steps;
		this.input = input;
		this.expout = expout;
		
	}
	
}
