package utils;

import java.io.FileInputStream;
import java.util.Properties;

public class ObjectReader {

	public static Properties readObjects()
	{
		
		try
		{
			
			FileInputStream fs =new FileInputStream("C:\\Users\\SHREYASH\\workspace\\SeleniumHybrid\\src\\objectRepository\\objects.properties");
			Properties prop =new Properties();
			prop.load(fs);
			return prop;
			
		}
		catch (Exception e) {
			// TODO: handle exception
			return null;
		}
	}
	
}