package abstractExample;

public abstract class absClass {

	public abstract void add(int a, int b);
	public abstract void sub(int a, int b);
	public  void mul(int a, int b)
	{
		System.out.println(a*b);
	}
	
	
}
