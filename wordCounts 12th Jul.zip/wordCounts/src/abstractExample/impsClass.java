package abstractExample;

public class impsClass extends absClass {

	@Override // @Override : is annotation means meta data
	public void add(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a+b);
	}

	@Override
	public void sub(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a-b);
		
	}

}
