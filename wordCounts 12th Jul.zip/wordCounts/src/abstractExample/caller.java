package abstractExample;

public class caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		absClass o = new impsClass();
		o.add(11, 22);
		o.sub(11, 22);
		o.mul(11, 22);
		
		
	}

}
