package inheritence;

//single level 
public class dcalc extends calc { //here dcalc is child class, and calc is parent or super class

	public void mul(int a, int b)
	{
		System.out.println("mul of two numbers : "+(a*b));
	}
	
	public void div(int a, int b)
	{
		System.out.println("div of two numbers : "+(a/b));
	}
	
	
	
}
