package inheritence;

//tree 
public class salary_cal extends calc {

	public void yearly_sal(int sal)
	{
		System.out.println("yearly salary is :"+(sal*12));
	}
}
