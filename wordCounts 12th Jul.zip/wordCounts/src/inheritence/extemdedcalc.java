package inheritence;

//multi level 

public class extemdedcalc extends dcalc {
	
	public void power(int n,int p)
	{
		System.out.println("power of given no. :"+(n^p));
		
	}
	
	public void freq(int n)
	{
		int f=1;
		
		while(n>1)
		{
				f*=n;
				n--;
		}
		System.out.println("fabancci ser... :"+f);
		
		
	}
}
