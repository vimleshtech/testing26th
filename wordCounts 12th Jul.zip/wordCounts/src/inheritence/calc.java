package inheritence;

public class calc {

	public void add(int a, int b)
	{
		System.out.println("sum of two numbers : "+(a+b));
	}
	public void sub(int a, int b)
	{
		System.out.println("sub of two numbers : "+(a-b));
	}
	
}
