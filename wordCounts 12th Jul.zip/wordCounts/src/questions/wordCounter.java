package questions;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;

public class wordCounter {

	public static void main(String[] args) {
		
		try
		{
			Scanner sc = new Scanner(System.in);
			String fname;
			System.out.println("enter file name : ");
			fname = sc.nextLine();
			
			
			FileReader fr =new FileReader("C:\\Users\\Tech Vision\\Desktop\\"+fname +".txt");
			BufferedReader br = new BufferedReader(fr);
			
			String line="";
			int wc=0;
			
			while( (line = br.readLine())!=null)
			{
				wc += line.split(" ").length;
				
			}
			System.out.println("word counts : "+wc);
			
		}
		catch (Exception e) {
			
		}

	}

}
