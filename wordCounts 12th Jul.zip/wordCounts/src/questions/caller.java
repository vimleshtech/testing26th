package questions;
import inheritence.*;

public class caller {

	public static void main(String[] args) {

		//here dcalc is child class, and d is an object of class
		//child class object can access to parent class member and functions
	
		//one level 
		/*
		dcalc d =new dcalc();
		d.add(11, 22);
		d.mul(11, 22);
		d.div(11, 22);
		d.sub(11, 22);
		*/
		//multi level 
		extemdedcalc e =new extemdedcalc();
		e.add(111, 22); 
		e.mul(11, 3);
		e.freq(6);
		
		//tree 
		dcalc dc = new dcalc();
		dc.add(11, 2);
		dc.mul(333, 33);
		
		salary_cal sc =new salary_cal();
		sc.add(111, 222);
		sc.yearly_sal(223333);
		
		
		

	}

}
