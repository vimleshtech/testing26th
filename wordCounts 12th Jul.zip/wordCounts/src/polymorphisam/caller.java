package polymorphisam;

import java.sql.Savepoint;

public class caller {

	public static void main(String[] args) {
	
		/*
		CurrentAccount ca =new CurrentAccount();
		ca.newAccount(111, "Nitin Wadhwa", "bsjhsjs", "tilak nagar", 120000);
		ca.showDetails();
		
		//call to child class function 
		ca.newAccount(111, "Nitin Wadhwa", "bsjhsjs", "tilak nagar", 120000,"gstn111");
		ca.showDetails();
		 */
		callToMethod(new CurrentAccount());
		callToMethod(new SavingAccount());
		
		//or
		SavingAccount ss = new SavingAccount();
		ss.showDetails();
		ss.add(11,33);
		ss.add(11,33,33);
		
		CurrentAccount ca = new CurrentAccount();
		ca.showDetails();
		
		ss = ca; //overriding
		ss.showDetails();  
		
		//or
		SavingAccount so1 = new CurrentAccount();
		so1.showDetails();
		
		
		
		
	}

	public static void callToMethod(SavingAccount so)
	{
		if(so instanceof SavingAccount)
			so.newAccount(111, "Nitin Wadhwa", "bsjhsjs", "tilak nagar", 120000);
		else			
			((CurrentAccount)so).newAccount(111, "Nitin Wadhwa", "bsjhsjs", "tilak nagar", 120000,"gstn111");
		
		so.showDetails();
	}
}
