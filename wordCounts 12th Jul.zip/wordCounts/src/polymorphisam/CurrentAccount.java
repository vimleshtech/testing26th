package polymorphisam;

public class CurrentAccount extends SavingAccount {

	String gstnno;
	
	public void newAccount(int acno, String aname, String panno, String address, int amt,String gstnno)
	{
		super.acno = acno;
		super.aname = aname;
		super.panno = panno;
		super.address = address;
		super.amout = amt;
		this.gstnno = gstnno;
		
	}
	
	public void showDetails()
	{
		super.showDetails();//call to parent class function 
		System.out.println("GSTN NO.: "+this.gstnno);
		
	}
	
}
