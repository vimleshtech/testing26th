package polymorphisam;



public class SavingAccount  {

	int acno;
	String aname;
	String panno;
	String address;
	int amout;
	void add(int a, int b)
	{
		System.out.println(a+b);
	}
	void add(int a, int b, int c)
	{
		System.out.println(a+b+c);
	}
	
	public void newAccount(int acno, String aname, String panno, String address, int amt)
	{
		this.acno = acno;
		this.aname = aname;
		this.panno = panno;
		this.address = address;
		this.amout = amt;
	}
	
	public void showDetails()
	{
		System.out.println("Account id : "+this.acno);
		System.out.println("Account name : "+this.aname);
		System.out.println("Account balanace : "+this.amout);
		
	}
	
}
