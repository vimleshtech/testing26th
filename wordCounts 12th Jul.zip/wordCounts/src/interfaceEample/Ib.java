package interfaceEample;

public interface Ib {

	void div(int a, int b);
}
