import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class fileWithStringExample {

	public static void main(String[] args) throws IOException {
		
		//wordCount();
		//charCount();
		writeData();
		
	}


	public static void writeData() throws IOException
	{
	
		Scanner sc = new Scanner(System.in);
		
		String fname;
		System.out.println("enter file name :");
		fname = sc.next();
		
		//(path,mode)
		//(path,true)   --append 
		//(path,false)  -- overwrite file (default)
		FileWriter fw = new FileWriter("C:\\Users\\vkumar15\\Desktop\\"+fname+".txt",true);
		BufferedWriter bw = new BufferedWriter(fw);
		
		while(true)
		{
			
			int op;
			System.out.println("enter 1. for add 2. for exit");
			op = sc.nextInt();
			if(op==1)
			{
				String data ;
				System.out.println("enter data to write : ");
				data =sc.next();
		
				bw.write(data);
				bw.newLine();
				
			}
			else if(op ==2)
			{
				break;
			}
			else
			{
				System.out.println("invalid option");
			}
		}
		bw.close();
		fw.close();
	
	}
	
	public static void rowCount() throws IOException
	{
		FileReader fr =new FileReader("C:\\Users\\vkumar15\\Desktop\\words.txt");
		
		BufferedReader br  = new BufferedReader(fr);
	
		int rc=0;
				
		while(  br.readLine() != null )
		{
			rc++;
		}
		System.out.println(rc);
		br.close();
		fr.close();
		

	}
	

	public static void wordCount() throws IOException
	{
		Scanner sc = new Scanner(System.in);
		String search;
		System.out.println("enter word to search :");
		search = sc.next();
		
		
		FileReader fr =new FileReader("C:\\Users\\vkumar15\\Desktop\\words.txt");
		
		BufferedReader br  = new BufferedReader(fr);
	
		int wc=0,pwc=0;
		String line ="";
				
		while( (line =  br.readLine()) != null )
		{
			String w[] = line.split(" ");			
			wc += w.length;
			System.out.println(w.length);
			
			for(String wo : w)
			{
				if(wo.equals(search))
					pwc++;
			}
			
		}
		
		System.out.println(wc);
		System.out.println(pwc);
		
		br.close();
		fr.close();
		

	}

	public static void charCount() throws IOException
	{
		Scanner sc = new Scanner(System.in);
		String search;
		System.out.println("enter word to search :");
		search = sc.next();
		
		
		FileReader fr =new FileReader("C:\\Users\\vkumar15\\Desktop\\words.txt");
		
		BufferedReader br  = new BufferedReader(fr);
	
		int wc=0,pwc=0;
		String line ="",str="";
				
		while( (line =  br.readLine()) != null )
		{
			str+=line;
		}
		
		//this is java code.java is grood prog...lan/.
		System.out.println(str.length()-str.replace(search, "").length());
		
		
		br.close();
		fr.close();
		

	}

	
	
	}
