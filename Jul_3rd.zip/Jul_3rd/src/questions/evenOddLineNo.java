package questions;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;


public class evenOddLineNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try
		{
		
			FileReader fr = new FileReader("C:\\Users\\DELL\\Desktop\\mydata\\data.txt");
			BufferedReader br = new BufferedReader(fr);
			
			FileWriter ef = new FileWriter("C:\\Users\\DELL\\Desktop\\mydata\\even.txt");
			BufferedWriter ew= new BufferedWriter(ef);
			
			FileWriter of = new FileWriter("C:\\Users\\DELL\\Desktop\\mydata\\odd.txt");
			BufferedWriter ow= new BufferedWriter(of);
			
			
			String data="";
			boolean even = false;
			
			while( (data= br.readLine() )!=null)
			{
	
				if(even)
				{
					ew.write(data);
					ew.newLine();
					even  = false;
				}
				else
				{
					ow.write(data);
					ow.newLine();
					even  = true;
				}
			}
			
			ow.close();
			of.close();
			ew.close();
			ef.close();
			br.close();
			fr.close();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

}
