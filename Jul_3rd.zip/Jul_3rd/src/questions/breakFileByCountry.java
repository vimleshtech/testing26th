package questions;

public class breakFileByCountry {

	public static void main(String[] args) {
		
		String data[] = {"java",".net","java","php","java","php"};
		String uq[]=new String[data.length];
		
		int ind=0;
		for(String x : data)
		{
			int isMatched = 0;
			for(String u : uq)
			{
				if(x.equals(u))
				{
					isMatched=1;
					break;
				}
			}
			if(isMatched ==0)
			{
				uq[ind] = x;
				ind++;
			}
		}
		
		
		for(int i=0; i<ind;i++)
		{
			System.out.println(uq[i]);
		}

	}

}
