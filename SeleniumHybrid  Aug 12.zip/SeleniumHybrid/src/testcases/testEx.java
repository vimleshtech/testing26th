package testcases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class testEx {
	
	
	@Test
	public void div()
	{
		int n,d,o;
		n=44;
		d =0;
		o = n/d;
		System.out.println(o);
	}
	@Test(dependsOnMethods={"div"})
	public void out()
	{
		System.out.println("out");
	}
  @Test(dataProvider = "dp",priority=1,groups={"a"})
  public void f(String un,String p, int a) {
  
	  System.out.println(un+"\t"+p+"\t"+a);
  
  
  }

  @Test(priority=2,enabled=true,groups={"a","b"})
	public void xy()
	{
		System.out.println("xy");
	}
  @Test(priority=2,enabled=true,groups={"b"})
	public void ab()
	{
		System.out.println("ab");
	}
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterMethod
  public void afterMethod() {
  }



  //Object : is class which can hold any types of data
  @DataProvider
  public Object[][] dp() 
  {
    return new Object[][] 
    		{
    			new Object[] { "nitin", "pwd1",31 },
    			new Object[] { "jyoti", "sss",27 },
    			new Object[] { "rahul", "sss",27 },
    			new Object[] { "jatin", "sss",27 },
    			
    		};
  }
  @BeforeClass
  public void beforeClass() {
  }

  @AfterClass
  public void afterClass() {
  }

  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

  @BeforeSuite
  public void beforeSuite() {
  }

  @AfterSuite
  public void afterSuite() {
  }

}
