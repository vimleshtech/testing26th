package testcases;

import org.junit.Test;

public class testClass2 {

	@Test
	public void test()
	{
		System.out.println("ab");
	}
}
