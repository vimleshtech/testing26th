package testcases;

import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class loginClass {

	static WebDriver driver =null;
	
	
	@Test
	public void test()
	{
		System.out.println("test login class");
		
		driver = new FirefoxDriver();
		driver.get("https://www.google.com/");
		
	}
	
	@Ignore
	@Test
	public void testLogin()
	{
		//driver.findElement(arg0)
		System.out.println("test login");
	}
}
