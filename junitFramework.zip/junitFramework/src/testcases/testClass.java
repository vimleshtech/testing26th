package testcases;

import org.junit.Test;

public class testClass {
	
	@Test
	public void test()
	{
		System.out.println("test");
	}

}
