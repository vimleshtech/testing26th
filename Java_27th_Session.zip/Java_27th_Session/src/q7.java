import java.util.Scanner;

public class q7 {

	public static void main(String[] args) {


		Scanner sc = new Scanner(System.in);
		int a,b,c,d;
		
		System.out.println("enter data : ");
		a = sc.nextInt();
		
		System.out.println("enter data : ");
		b = sc.nextInt();
		
		System.out.println("enter data : ");
		c = sc.nextInt();
		
		System.out.println("enter data : ");
		d = sc.nextInt();
		
		
		if((a*a*a+b*b*b+c*c*c) == (d*d*d))
		{
				System.out.println("condition matched");
		}
		else
		{
				System.out.println("condition not matched");
		}
	}

}
