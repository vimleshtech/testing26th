package stringex;

import java.util.Scanner;

public class extringManipulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		String name,nstr ;
		
		System.out.println("enter name :");
		name = sc.nextLine();  //this is 
		
		System.out.println(name);
		
		nstr = name.toUpperCase();
		System.out.println(nstr);
		
		nstr = name.toLowerCase();
		System.out.println(nstr);
		
		int l = name.length();
		System.out.println(l);
		
		nstr = name.trim();
		l = nstr.length();
		
		System.out.println(l);
		
		
		nstr=name.replace("a", "xy");
		System.out.println(nstr);
		
		
		nstr = name.concat("end");
		nstr  =name+"end";
		
		System.out.println(nstr);
		
		
		//raman sinha
		nstr = name.substring(2,5);
		System.out.println(nstr);
		
		
		int ps;
		ps = name.indexOf("a");
		
		char c;
		c = name.charAt(2);
		System.out.println(c);
		
		//convert char to ascii
		
		int a =c;
		System.out.println(a);
		
		//split : string to words/char
		//raman kumar sinha = ["raman","kumar","sinha"]

		String dd[] = name.split(" ");
		System.out.println(dd[0]);
		
		
		////
		if(name.equals("raman"))
		{
			System.out.println("name is raman");
		}
		else
		{
			System.out.println("name is not raman");
		}
		
		//
		if(name.equalsIgnoreCase("RAman"))
		{
			System.out.println("name is raman - not case sen..");
		}
		else
		{
			System.out.println("name is not raman");
		}
		
		//
		if(name.contains("m"))
		{
			
			System.out.println("m exist");
		}
		else
		{
			System.out.println("m doesn't exist");
		}
		//
		if(name.startsWith("r"))
		{
			System.out.println("start with r");
		}
		else
		{
			System.out.println("not start with r");
		}
		//
		if(name.endsWith("a"))
		{
		System.out.println("end with a");	
		}
		else
		{
			System.out.println("not end with a");
		}
		
		
		
	}

}
