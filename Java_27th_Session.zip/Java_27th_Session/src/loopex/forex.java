package loopex;

import java.util.Scanner;

public class forex {

	public static void main(String[] args) {
		
		for(int i=0;i<10;i++)
		{
			System.out.println(i);
		}
		
		for(int i=10;i>0;i--)
		{
			System.out.println(i);
		}
		
		///
		Scanner sc = new Scanner(System.in);
		
		int n1,n2,se=0,so=0;
		System.out.println("enter start no . :");
		n1 = sc.nextInt(); //5
		System.out.println("enter end no. :");
		n2 = sc.nextInt(); //50
	
		for(int i=n1; i<=n2;i++)
		{
			if(i%2==0)			
				se +=i;			
			else			
				so +=i;
			
		
		}
		System.out.println(so);
		System.out.println(se);
		
	}

}
