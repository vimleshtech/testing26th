package loopex;

import java.util.Scanner;

public class whileex {

	public static void main(String[] args) {
		
		int i=1;  //init 		
		while(i<=10) //condition 
		{
			
			System.out.print(i+"\t");
			i++ ;// incrementer 
		}

		System.out.println("number in reverse order");
		i =10 ; //start
		while(i>0) {
			
			System.out.println(i);
			i--;
		}
		
		
		/// print all odd numbers between 1 to 30
		i =1;
		while(i<=30)
		{
			System.out.println(i);
			i+=2;
			/*
			if(i%2>0) // 1/2 = 0.5
			{
				System.out.println(i);
			}
			i+=1;
			*/
			
		}
		
		///wap to print table of given no
		Scanner sc = new Scanner(System.in);
		System.out.println("enter no. to print table :");
		int t = sc.nextInt();
		
		
		i=1;
		while(i<=10) {
			
			System.out.println(t+"*"+i+"="+(t*i) );
			
			i++;
		}
		
		
		//// wap to print sum of all even, and odd numbers between two given range
		int n1,n2,se=0,so=0;
		System.out.println("enter start no . :");
		n1 = sc.nextInt(); //5
		System.out.println("enter end no. :");
		n2 = sc.nextInt(); //50
		
		while(n1<=n2) {
			
			
			if(n1%2==0)			
				se +=n1;			
			else			
				so +=n1;
			
			n1++;			
		}
		System.out.println("sum of all odd numbers :"+so);
		System.out.println("sum of all even numbers :"+se);
		
	}

}
