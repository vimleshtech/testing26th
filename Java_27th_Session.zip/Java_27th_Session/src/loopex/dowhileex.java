package loopex;

public class dowhileex {

	public static void main(String[] args) {
		
		//do while : will execute at least once 
		
		int i=0;		
		do {
			
			System.out.println(i);
			i++;
		}while(i<0);
		
	}

}
