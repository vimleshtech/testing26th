package loopex;

public class foreachex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n[] = {111,2,2,3,3,4,5,5};
		int sum=0;

		//advance loop/foreach is forward only
		for(int x : n) // here x is new variable , n is array 
		{
			sum +=x;
			
		}
		System.out.println("sum of all numbers :"+sum);
	}

}
