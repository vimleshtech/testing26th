package loopex;

public class nestedloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//i = 0 , c =1 2 3 4 
		//i = 1 , c =1 2 3 4
		//i = 2 , c =1 2 3 4
		
		for(int i=0;i<3;i++) //rows 
		{
			for(int c=1; c<5;c++) //cols
			{
				System.out.print("*");
			}
			System.out.println();
		}
		
		
		//i =1 , c = 1
		//i =2 , c =1 2 
		//i =3 , c =1 2 3 
		
		for(int i=1;i<=3;i++) //rows 
		{
			for(int c=1; c<=i;c++) //cols
			{
				System.out.print(c);
			}
			System.out.println();
		}
		
		///

		for(int i=1;i<=3;i++) //rows 
		{
			for(int c=i; c<=3;c++) //cols
			{
				System.out.print('*');
			}
			System.out.println();
		}
		
	}

}
