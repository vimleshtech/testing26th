import java.util.Scanner;

public class doubts 
{
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int sal;
		double hra=0,da=0;
		
		
		System.out.println("enter salary :");
		sal = sc.nextInt();
		
		
		if(sal>=5000 && sal<10000)
		{
			hra = sal*.10;
			da = sal*.05;
		}
		else if(sal>=10000 && sal<15000)
		{
			hra = sal*.15;
			da = sal*.08;		
		}
		
		System.out.println("HRA = "+hra);
		System.out.println("DA= "+da);
		
		
	}

}
